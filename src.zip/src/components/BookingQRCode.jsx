
import React from "react";

export default function BookingQRCode({
  qrCode,
  bookingReference,
}) {
  if (!qrCode) {
    return (
      <div className="qr-empty">
        QR code is not available for this booking.
      </div>
    );
  }

  return (
    <section className="booking-qr-card">
      <div className="booking-qr-header">
        <div>
          <h3>Your Parking QR Code</h3>
          <p>Show this code to your parking guard.</p>
        </div>

        <span className="qr-status">Ready to scan</span>
      </div>

      <div className="booking-qr-image">
        <img
          src={qrCode}
          alt={`Parking QR code for booking ${bookingReference || ""}`}
        />
      </div>

      {bookingReference && (
        <p className="booking-qr-reference">
          Booking reference: <strong>{bookingReference}</strong>
        </p>
      )}

      <p className="booking-qr-instructions">
        Keep this code available on your phone. Present the same code
        when entering and exiting the parking location.
      </p>
    </section>
  );
}

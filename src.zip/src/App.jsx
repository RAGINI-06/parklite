import { useEffect, useState } from "react";

import { motion } from "framer-motion";

import {

  ArrowUpRight,

  MapPin,

  Search,

  ShieldCheck,

  Clock3,

  CarFront,

  Zap,

  Menu,

  X,

  LoaderCircle,

  QrCode,

  CalendarClock,

  LogIn,

  UserPlus,

  CheckCircle2,

  AlertCircle,

} from "lucide-react";

import { api } from "./api";

import "./index.css";

const inputStyle = {

  width: "100%",

  padding: "12px 14px",

  border: "1px solid #d9ded8",

  borderRadius: "10px",

  fontSize: "14px",

  background: "#fff",

  color: "#202820",

  boxSizing: "border-box",

};

const primaryStyle = {

  width: "100%",

  padding: "13px 16px",

  border: "none",

  borderRadius: "10px",

  background: "#c9f36b",

  color: "#172015",

  fontWeight: 700,

  cursor: "pointer",

  fontSize: "14px",

};

function getPayload(response) {

  if (response?.data != null) return response.data;

  return response;

}

function getLots(response) {

  const payload = getPayload(response);

  if (Array.isArray(payload)) return payload;

  if (Array.isArray(payload?.parkingLots)) return payload.parkingLots;

  if (Array.isArray(payload?.lots)) return payload.lots;

  if (Array.isArray(payload?.rows)) return payload.rows;

  return [];

}

function getBooking(response) {

  const payload = getPayload(response);

  if (payload?.booking) {

    return { ...payload.booking, qrCode: payload.qrCode ?? payload.booking.qrCode };

  }

  return payload;

}

function formatDateTime(value) {

  if (!value) return "Not available";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleString();

}

function App() {

  const [location, setLocation] = useState("");

  const [parkingLocations, setParkingLocations] = useState([]);

  const [filtered, setFiltered] = useState([]);

  const [loadingParking, setLoadingParking] = useState(true);

  const [apiError, setApiError] = useState("");

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [authToken, setAuthToken] = useState(

    () => localStorage.getItem("parklite_token") || ""

  );

  const [authMode, setAuthMode] = useState("login");

  const [authOpen, setAuthOpen] = useState(false);

  const [authLoading, setAuthLoading] = useState(false);

  const [authError, setAuthError] = useState("");

  const [authSuccess, setAuthSuccess] = useState("");

  const [authForm, setAuthForm] = useState({

    full_name: "",

    email: "",

    password: "",

  });

  const [selectedParking, setSelectedParking] = useState(null);

  const [bookingLoading, setBookingLoading] = useState(false);

  const [bookingError, setBookingError] = useState("");

  const [bookingSuccess, setBookingSuccess] = useState("");

  const [bookingResult, setBookingResult] = useState(null);

  const [bookingForm, setBookingForm] = useState({

    vehicle_number: "",

    start_time: "",

    end_time: "",

  });

  useEffect(() => {

    let cancelled = false;

    async function loadParking() {

      setLoadingParking(true);

      setApiError("");

      try {

        const response = await api.getParkingLots();

        const lots = getLots(response);

        const mappedLots = lots.map((lot) => ({

          ...lot,

          id: lot.id,

          name: lot.name ?? lot.lot_name ?? "Parking location",

          location: [lot.address, lot.city].filter(Boolean).join(", ") ||

            lot.location ||

            "Location not specified",

          price: Number(lot.hourly_rate ?? lot.hourlyRate ?? lot.rate ?? 0),

          available:

            lot.available_spots ??

            lot.availableSpaces ??

            lot.available ??

            null,

          total: Number(

            lot.total_capacity ?? lot.totalCapacity ?? lot.capacity ?? 0

          ),

          type: lot.type ?? lot.parking_type ?? "Parking",

        }));

        if (!cancelled) {

          setParkingLocations(mappedLots);

          setFiltered(mappedLots);

        }

      } catch (error) {

        if (!cancelled) {

          setApiError(

            error.message ||

              "Could not connect to the parking server. Check that your backend is running."

          );

        }

      } finally {

        if (!cancelled) setLoadingParking(false);

      }

    }

    loadParking();

    return () => {

      cancelled = true;

    };

  }, []);

  function searchParking(event) {

    event.preventDefault();

    const query = location.trim().toLowerCase();

    const results = parkingLocations.filter((parking) => {

      const searchableText =

        `${parking.name} ${parking.location} ${parking.type}`.toLowerCase();

      return searchableText.includes(query);

    });

    setFiltered(results);

    document.getElementById("parking")?.scrollIntoView({

      behavior: "smooth",

    });

  }

  function openBooking(parking) {

    setSelectedParking(parking);

    setBookingError("");

    setBookingSuccess("");

    setBookingResult(null);

    const now = new Date();

    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());

    const start = now.toISOString().slice(0, 16);

    const endDate = new Date(now.getTime() + 60 * 60 * 1000);

    const end = endDate.toISOString().slice(0, 16);

    setBookingForm({

      vehicle_number: "",

      start_time: start,

      end_time: end,

    });

    if (!authToken) {

      setAuthMode("login");

      setAuthError("");

      setAuthSuccess("");

      setAuthOpen(true);

    }

  }

  async function submitAuth(event) {

    event.preventDefault();

    setAuthLoading(true);

    setAuthError("");

    setAuthSuccess("");

    try {

      const credentials = {

        email: authForm.email.trim(),

        password: authForm.password,

      };

      let response;

      if (authMode === "register") {

        response = await api.register({

          full_name: authForm.full_name.trim(),

          ...credentials,

        });

      } else {

        response = await api.login(credentials);

      }

      const payload = getPayload(response);

      const token =

        payload?.token ??

        payload?.accessToken ??

        payload?.access_token ??

        response?.token;

      if (token) {

        localStorage.setItem("parklite_token", token);

        setAuthToken(token);

        setAuthOpen(false);

        setAuthError("");

        setAuthSuccess("");

        setAuthForm({ full_name: "", email: "", password: "" });

      } else if (authMode === "register") {

        setAuthMode("login");

        setAuthSuccess(

          "Account created. Please log in with your new account."

        );

      } else {

        throw new Error(

          "Login response did not include a token. Check your backend response format."

        );

      }

    } catch (error) {

      setAuthError(error.message || "Authentication failed.");

    } finally {

      setAuthLoading(false);

    }

  }

  function logout() {

    localStorage.removeItem("parklite_token");

    setAuthToken("");

    setBookingSuccess("");

    setBookingResult(null);

  }

  async function submitBooking(event) {

    event.preventDefault();

    setBookingError("");

    setBookingSuccess("");

    setBookingResult(null);

    if (!authToken) {

      setBookingError("Please log in before making a booking.");

      setAuthOpen(true);

      return;

    }

    if (!selectedParking?.id) {

      setBookingError("Please select a valid parking location.");

      return;

    }

    const vehicleNumber = bookingForm.vehicle_number

      .trim()

      .toUpperCase();

    if (!/^[A-Z0-9 -]{4,20}$/.test(vehicleNumber)) {

      setBookingError(

        "Enter a valid vehicle number using 4–20 letters, numbers, spaces or hyphens."

      );

      return;

    }

    if (

      !bookingForm.start_time ||

      !bookingForm.end_time ||

      new Date(bookingForm.end_time) <=

        new Date(bookingForm.start_time)

    ) {

      setBookingError("End time must be later than start time.");

      return;

    }

    setBookingLoading(true);

    try {

      const response = await api.createBooking(

        {

          parking_lot_id: selectedParking.id,

          vehicle_number: vehicleNumber,

          start_time: new Date(bookingForm.start_time).toISOString(),

          end_time: new Date(bookingForm.end_time).toISOString(),

        },

        authToken

      );

      const booking = getBooking(response);

      setBookingResult(booking);

      setBookingSuccess("Your parking booking was created successfully.");

      // Refresh the parking list after a successful booking.

      try {

        const latest = await api.getParkingLots();

        const lots = getLots(latest);

        const mappedLots = lots.map((lot) => ({

          ...lot,

          id: lot.id,

          name: lot.name ?? lot.lot_name ?? "Parking location",

          location:

            [lot.address, lot.city].filter(Boolean).join(", ") ||

            lot.location ||

            "Location not specified",

          price: Number(

            lot.hourly_rate ?? lot.hourlyRate ?? lot.rate ?? 0

          ),

          available:

            lot.available_spots ??

            lot.availableSpaces ??

            lot.available ??

            null,

          total: Number(

            lot.total_capacity ??

              lot.totalCapacity ??

              lot.capacity ??

              0

          ),

          type: lot.type ?? lot.parking_type ?? "Parking",

        }));

        setParkingLocations(mappedLots);

        setFiltered(

          mappedLots.filter((parking) => {

            const query = location.trim().toLowerCase();

            return `${parking.name} ${parking.location} ${parking.type}`

              .toLowerCase()

              .includes(query);

          })

        );

      } catch {

        // The booking is already successful; a refresh failure should not hide it.

      }

    } catch (error) {

      if (

        error.message?.toLowerCase().includes("token") ||

        error.message?.includes("401")

      ) {

        localStorage.removeItem("parklite_token");

        setAuthToken("");

      }

      setBookingError(error.message || "Could not create the booking.");

    } finally {

      setBookingLoading(false);

    }

  }

  const closeBooking = () => {

    setSelectedParking(null);

    setBookingError("");

    setBookingSuccess("");

    setBookingResult(null);

  };

  return (

    <div className="app-shell">

      <div className="ambient ambient-one" />

      <div className="ambient ambient-two" />

      <header className="navbar">

        <a className="brand" href="#">

          <span className="brand-icon">

            <CarFront size={23} strokeWidth={2.5} />

            <span className="brand-dot" />

          </span>

          <span>

            Park<span className="yellow">Lite</span>

          </span>

        </a>

        <nav className={`nav-links ${mobileMenuOpen ? "mobile-open" : ""}`}>

          <a className="active" href="#" onClick={() => setMobileMenuOpen(false)}>

            Home

          </a>

          <a href="#parking" onClick={() => setMobileMenuOpen(false)}>

            Find Parking

          </a>

          <a

            href="#how-it-works"

            onClick={() => setMobileMenuOpen(false)}

          >

            How it works

          </a>

        </nav>

        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>

          {authToken ? (

            <button

              type="button"

              className="nav-cta"

              onClick={logout}

              style={{ cursor: "pointer" }}

            >

              Log out

            </button>

          ) : (

            <button

              type="button"

              className="nav-cta"

              onClick={() => {

                setAuthMode("login");

                setAuthError("");

                setAuthSuccess("");

                setAuthOpen(true);

              }}

              style={{ cursor: "pointer" }}

            >

              Log in <ArrowUpRight size={18} />

            </button>

          )}

          <button

            className="mobile-menu"

            aria-label="Toggle menu"

            type="button"

            onClick={() => setMobileMenuOpen((open) => !open)}

          >

            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}

          </button>

        </div>

      </header>

      <main>

        <section className="hero">

          <motion.div

            className="hero-copy"

            initial={{ opacity: 0, y: 24 }}

            animate={{ opacity: 1, y: 0 }}

            transition={{ duration: 0.6 }}

          >

            <div className="eyebrow">

              <span className="live-dot" />

              SMART PARKING. LESS STRESS.

            </div>

            <h1>

              Your parking.

              <br />

              <span className="hero-highlight">Your time.</span>

              <br />

              Your way.

            </h1>

            <p className="hero-description">

              Find a spot before you arrive. Compare prices, check

              availability and reserve parking without the last-minute

              hunt.

            </p>

            <div className="hero-actions">

              <a className="primary-btn" href="#parking">

                Find my parking <ArrowUpRight size={19} />

              </a>

              <a className="secondary-btn" href="#how-it-works">

                How it works

              </a>

            </div>

            <div className="hero-trust">

              <div className="trust-item">

                <ShieldCheck size={19} />

                <span>Secure bookings</span>

              </div>

              <div className="trust-item">

                <Clock3 size={19} />

                <span>Save your time</span>

              </div>

            </div>

          </motion.div>

          <motion.div

            className="hero-visual"

            initial={{ opacity: 0, scale: 0.96 }}

            animate={{ opacity: 1, scale: 1 }}

            transition={{ duration: 0.7 }}

          >

            <div className="visual-top">

              <span className="visual-label">PARKING OVERVIEW</span>

              <span className="live-status">

                <span className="live-dot" /> LIVE PREVIEW

              </span>

            </div>

            <div className="parking-art">

              <div className="art-grid" />

              <div className="parking-lines">

                {Array.from({ length: 5 }, (_, i) => (

                  <div className="parking-slot" key={i}>

                    <span className="slot-number">P{i + 1}</span>

                    {i === 2 ? (

                      <CarFront

                        className="slot-car featured-car"

                        size={38}

                      />

                    ) : (

                      <CarFront className="slot-car" size={31} />

                    )}

                  </div>

                ))}

              </div>

              <div className="map-pin pin-one">

                <MapPin size={16} /> Available

              </div>

              <div className="map-pin pin-two">

                <MapPin size={16} /> Your destination

              </div>

              <div className="art-caption">

                <span className="caption-icon">

                  <Zap size={17} />

                </span>

                <div>

                  <strong>Park smarter.</strong>

                  <p>Spend less time searching.</p>

                </div>

              </div>

            </div>

            <div className="visual-stats">

              <div>

                <span className="stat-label">Availability</span>

                <strong>

                  {loadingParking

                    ? "Loading locations..."

                    : apiError

                      ? "Connection needed"

                      : `${parkingLocations.length} locations loaded`}

                </strong>

              </div>

              <div className="stat-right">

                <span className="availability-bars">

                  <i />

                  <i />

                  <i />

                  <i />

                  <i />

                </span>

                <span className="stat-label">Find your spot</span>

              </div>

            </div>

          </motion.div>

        </section>

        <section className="search-section">

          <form className="search-bar" onSubmit={searchParking}>

            <div className="search-field">

              <MapPin size={22} />

              <div className="search-input-wrap">

                <label htmlFor="location">WHERE ARE YOU GOING?</label>

                <input

                  id="location"

                  value={location}

                  onChange={(event) => setLocation(event.target.value)}

                  placeholder="Search parking or area..."

                />

              </div>

            </div>

            <button type="submit" className="search-btn">

              <Search size={19} /> Find parking

            </button>

          </form>

          <p className="search-hint">

            Search by parking name, address or city

          </p>

        </section>

        <section className="parking-section" id="parking">

          <div className="section-heading">

            <div>

              <span className="eyebrow">YOUR NEXT PARKING SPOT</span>

              <h2>

                Parking, <span className="yellow">simplified.</span>

              </h2>

              <p>Parking locations loaded from the ParkLite backend.</p>

            </div>

            <span className="results-count">

              {filtered.length} locations

            </span>

          </div>

          {loadingParking && (

            <div className="empty-state" role="status">

              <LoaderCircle size={28} className="spin-icon" />

              <h3>Loading parking locations...</h3>

              <p>Connecting to your parking server.</p>

            </div>

          )}

          {!loadingParking && apiError && (

            <div className="empty-state" role="alert">

              <AlertCircle size={28} />

              <h3>Could not load parking locations</h3>

              <p>{apiError}</p>

              <button

                type="button"

                className="secondary-btn"

                onClick={() => window.location.reload()}

              >

                Try again

              </button>

            </div>

          )}

          {!loadingParking && !apiError && (

            <>

              <div className="parking-grid">

                {filtered.map((parking, index) => (

                  <motion.article

                    className="parking-card"

                    key={parking.id ?? parking.name}

                    initial={{ opacity: 0, y: 18 }}

                    whileInView={{ opacity: 1, y: 0 }}

                    viewport={{ once: true }}

                    transition={{ delay: index * 0.1 }}

                  >

                    <div className="card-art">

                      <div className="card-art-grid" />

                      <span className="parking-type">{parking.type}</span>

                      <CarFront size={72} strokeWidth={1.2} />

                      <span className="card-availability">

                        <span className="live-dot" />

                        {parking.available == null

                          ? "Check availability"

                          : `${parking.available} spots available`}

                      </span>

                    </div>

                    <div className="card-content">

                      <div className="card-title-row">

                        <h3>{parking.name}</h3>

                        <ArrowUpRight size={19} />

                      </div>

                      <p className="card-location">

                        <MapPin size={15} /> {parking.location}

                      </p>

                      <div className="card-divider" />

                      <div className="card-bottom">

                        <div className="price">

                          <strong>₹{parking.price}</strong>

                          <span>/ hour</span>

                        </div>

                        <button

                          type="button"

                          className="card-btn"

                          onClick={() => openBooking(parking)}

                        >

                          Book parking <ArrowUpRight size={16} />

                        </button>

                      </div>

                    </div>

                  </motion.article>

                ))}

              </div>

              {filtered.length === 0 && (

                <div className="empty-state">

                  <Search size={28} />

                  <h3>No matching parking locations</h3>

                  <p>Try another location or parking name.</p>

                  <button

                    type="button"

                    className="secondary-btn"

                    onClick={() => {

                      setLocation("");

                      setFiltered(parkingLocations);

                    }}

                  >

                    Show all locations

                  </button>

                </div>

              )}

            </>

          )}

        </section>

        <section className="how-section" id="how-it-works">

          <span className="eyebrow">THREE STEPS. ZERO HASSLE.</span>

          <h2>

            From search to <span className="yellow">parked.</span>

          </h2>

          <div className="steps-grid">

            {[

              [

                "01",

                "Find a spot",

                "Search parking locations and compare availability.",

              ],

              [

                "02",

                "Reserve your space",

                "Choose your duration and review the estimated cost.",

              ],

              [

                "03",

                "Arrive and park",

                "Show your booking QR code to the parking guard.",

              ],

            ].map(([number, title, description]) => (

              <div className="step-card" key={number}>

                <span className="step-number">{number}</span>

                <h3>{title}</h3>

                <p>{description}</p>

              </div>

            ))}

          </div>

        </section>

      </main>

      <footer className="footer">

        <a className="brand" href="#">

          <span className="brand-icon">

            <CarFront size={21} />

          </span>

          <span>

            Park<span className="yellow">Lite</span>

          </span>

        </a>

        <p>Built for a smarter parking experience.</p>

        <span className="footer-copy">© 2026 ParkLite</span>

      </footer>

      {/* Authentication modal */}

      {authOpen && (

        <div

          role="presentation"

          onClick={(event) => {

            if (event.target === event.currentTarget) setAuthOpen(false);

          }}

          style={overlayStyle}

        >

          <div

            role="dialog"

            aria-modal="true"

            aria-labelledby="auth-title"

            style={modalStyle}

          >

            <button

              type="button"

              aria-label="Close login"

              onClick={() => setAuthOpen(false)}

              style={closeButtonStyle}

            >

              <X size={20} />

            </button>

            <div style={modalIconStyle}>

              {authMode === "login" ? (

                <LogIn size={24} />

              ) : (

                <UserPlus size={24} />

              )}

            </div>

            <h2 id="auth-title" style={{ margin: "0 0 8px" }}>

              {authMode === "login" ? "Welcome back" : "Create your account"}

            </h2>

            <p style={{ color: "#697267", marginTop: 0, fontSize: 14 }}>

              {authMode === "login"

                ? "Log in to reserve your parking spot."

                : "Register to start booking with ParkLite."}

            </p>

            {authError && (

              <p style={errorBoxStyle} role="alert">

                {authError}

              </p>

            )}

            {authSuccess && (

              <p style={successBoxStyle} role="status">

                {authSuccess}

              </p>

            )}

            <form

              onSubmit={submitAuth}

              style={{ display: "grid", gap: 14, marginTop: 20 }}

            >

              {authMode === "register" && (

                <label style={labelStyle}>

                  Full name

                  <input

                    required

                    autoComplete="name"

                    style={inputStyle}

                    value={authForm.full_name}

                    onChange={(event) =>

                      setAuthForm({

                        ...authForm,

                        full_name: event.target.value,

                      })

                    }

                    placeholder="Your full name"

                  />

                </label>

              )}

              <label style={labelStyle}>

                Email address

                <input

                  required

                  type="email"

                  autoComplete="email"

                  style={inputStyle}

                  value={authForm.email}

                  onChange={(event) =>

                    setAuthForm({ ...authForm, email: event.target.value })

                  }

                  placeholder="you@example.com"

                />

              </label>

              <label style={labelStyle}>

                Password

                <input

                  required

                  type="password"

                  minLength={6}

                  autoComplete={

                    authMode === "login" ? "current-password" : "new-password"

                  }

                  style={inputStyle}

                  value={authForm.password}

                  onChange={(event) =>

                    setAuthForm({

                      ...authForm,

                      password: event.target.value,

                    })

                  }

                  placeholder="Enter your password"

                />

              </label>

              <button

                type="submit"

                disabled={authLoading}

                style={{

                  ...primaryStyle,

                  opacity: authLoading ? 0.7 : 1,

                }}

              >

                {authLoading

                  ? "Please wait..."

                  : authMode === "login"

                    ? "Log in"

                    : "Create account"}

              </button>

            </form>

            <p

              style={{

                fontSize: 14,

                textAlign: "center",

                color: "#697267",

                marginBottom: 0,

              }}

            >

              {authMode === "login"

                ? "New to ParkLite? "

                : "Already have an account? "}

              <button

                type="button"

                onClick={() => {

                  setAuthMode(authMode === "login" ? "register" : "login");

                  setAuthError("");

                  setAuthSuccess("");

                }}

                style={textButtonStyle}

              >

                {authMode === "login" ? "Create an account" : "Log in"}

              </button>

            </p>

          </div>

        </div>

      )}

      {/* Booking modal */}

      {selectedParking && (

        <div

          role="presentation"

          onClick={(event) => {

            if (event.target === event.currentTarget) closeBooking();

          }}

          style={overlayStyle}

        >

          <div

            role="dialog"

            aria-modal="true"

            aria-labelledby="booking-title"

            style={modalStyle}

          >

            <button

              type="button"

              aria-label="Close booking"

              onClick={closeBooking}

              style={closeButtonStyle}

            >

              <X size={20} />

            </button>

            {!bookingSuccess ? (

              <>

                <div style={modalIconStyle}>

                  <CalendarClock size={24} />

                </div>

                <h2 id="booking-title" style={{ margin: "0 0 8px" }}>

                  Reserve your spot

                </h2>

                <p style={{ color: "#697267", marginTop: 0, fontSize: 14 }}>

                  {selectedParking.name}

                </p>

                <p

                  style={{

                    display: "flex",

                    alignItems: "center",

                    gap: 6,

                    fontSize: 13,

                    color: "#697267",

                  }}

                >

                  <MapPin size={15} /> {selectedParking.location}

                </p>

                {!authToken && (

                  <p style={errorBoxStyle}>

                    Please log in to continue with your booking.

                    <button

                      type="button"

                      style={{ ...textButtonStyle, marginLeft: 5 }}

                      onClick={() => {

                        setAuthMode("login");

                        setAuthOpen(true);

                      }}

                    >

                      Log in

                    </button>

                  </p>

                )}

                {bookingError && (

                  <p style={errorBoxStyle} role="alert">

                    {bookingError}

                  </p>

                )}

                <form

                  onSubmit={submitBooking}

                  style={{ display: "grid", gap: 14, marginTop: 18 }}

                >

                  <label style={labelStyle}>

                    Vehicle number

                    <input

                      required

                      style={inputStyle}

                      value={bookingForm.vehicle_number}

                      onChange={(event) =>

                        setBookingForm({

                          ...bookingForm,

                          vehicle_number: event.target.value.toUpperCase(),

                        })

                      }

                      placeholder="e.g. UP32AB1234"

                    />

                  </label>

                  <label style={labelStyle}>

                    Start time

                    <input

                      required

                      type="datetime-local"

                      style={inputStyle}

                      value={bookingForm.start_time}

                      onChange={(event) =>

                        setBookingForm({

                          ...bookingForm,

                          start_time: event.target.value,

                        })

                      }

                    />

                  </label>

                  <label style={labelStyle}>

                    End time

                    <input

                      required

                      type="datetime-local"

                      style={inputStyle}

                      min={bookingForm.start_time || undefined}

                      value={bookingForm.end_time}

                      onChange={(event) =>

                        setBookingForm({

                          ...bookingForm,

                          end_time: event.target.value,

                        })

                      }

                    />

                  </label>

                  <div

                    style={{

                      padding: 14,

                      borderRadius: 10,

                      background: "#f4f7ef",

                      display: "flex",

                      alignItems: "center",

                      justifyContent: "space-between",

                    }}

                  >

                    <span style={{ fontSize: 14, color: "#697267" }}>

                      Hourly rate

                    </span>

                    <strong style={{ fontSize: 18 }}>

                      ₹{selectedParking.price}/hour

                    </strong>

                  </div>

                  <button

                    type="submit"

                    disabled={bookingLoading || !authToken}

                    style={{

                      ...primaryStyle,

                      opacity: bookingLoading || !authToken ? 0.65 : 1,

                    }}

                  >

                    {bookingLoading

                      ? "Creating booking..."

                      : "Confirm booking"}

                  </button>

                </form>

              </>

            ) : (

              <div style={{ textAlign: "center" }}>

                <CheckCircle2

                  size={44}

                  color="#4b8c32"

                  style={{ marginBottom: 10 }}

                />

                <h2 id="booking-title">Booking confirmed!</h2>

                <p style={{ color: "#697267", fontSize: 14 }}>

                  {bookingSuccess}

                </p>

                {bookingResult?.booking_reference && (

                  <p style={referenceStyle}>

                    Booking reference:{" "}

                    <strong>{bookingResult.booking_reference}</strong>

                  </p>

                )}

                {bookingResult?.qrCode ? (

                  <div style={{ margin: "20px 0" }}>

                    <p style={{ fontSize: 14 }}>

                      Show this QR code to the parking guard at entry and exit.

                    </p>

                    <img

                      src={bookingResult.qrCode}

                      alt="Parking booking QR code"

                      style={{

                        width: 220,

                        maxWidth: "100%",

                        border: "1px solid #e0e5dd",

                        borderRadius: 12,

                        padding: 10,

                        background: "#fff",

                      }}

                    />

                  </div>

                ) : (

                  <p style={{ fontSize: 13, color: "#697267" }}>

                    Your booking was created, but the response did not include

                    a QR image. Open your booking details to retrieve it.

                  </p>

                )}

                {bookingResult?.start_time && (

                  <p style={{ fontSize: 13, color: "#697267" }}>

                    Start: {formatDateTime(bookingResult.start_time)}

                  </p>

                )}

                {bookingResult?.end_time && (

                  <p style={{ fontSize: 13, color: "#697267" }}>

                    End: {formatDateTime(bookingResult.end_time)}

                  </p>

                )}

                <button

                  type="button"

                  style={primaryStyle}

                  onClick={closeBooking}

                >

                  Done

                </button>

              </div>

            )}

          </div>

        </div>

      )}

    </div>

  );

}

const overlayStyle = {

  position: "fixed",

  inset: 0,

  zIndex: 1000,

  background: "rgba(13, 20, 13, 0.62)",

  display: "flex",

  alignItems: "center",

  justifyContent: "center",

  padding: 16,

  overflowY: "auto",

};

const modalStyle = {

  position: "relative",

  width: "100%",

  maxWidth: 440,

  maxHeight: "90vh",

  overflowY: "auto",

  background: "#fff",

  color: "#202820",

  borderRadius: 18,

  padding: 26,

  boxShadow: "0 24px 80px rgba(0,0,0,0.2)",

  boxSizing: "border-box",

};

const closeButtonStyle = {

  position: "absolute",

  top: 14,

  right: 14,

  display: "grid",

  placeItems: "center",

  width: 36,

  height: 36,

  border: "none",

  borderRadius: 9,

  background: "#f1f4ee",

  cursor: "pointer",

  color: "#202820",

};

const modalIconStyle = {

  width: 48,

  height: 48,

  borderRadius: 13,

  background: "#eff8df",

  color: "#426a25",

  display: "grid",

  placeItems: "center",

  marginBottom: 18,

};

const labelStyle = {

  display: "grid",

  gap: 7,

  fontSize: 13,

  fontWeight: 600,

  color: "#344034",

};

const errorBoxStyle = {

  background: "#fff1ef",

  color: "#a33428",

  padding: 12,

  borderRadius: 9,

  fontSize: 13,

  lineHeight: 1.5,

};

const successBoxStyle = {

  background: "#eff8df",

  color: "#426a25",

  padding: 12,

  borderRadius: 9,

  fontSize: 13,

  lineHeight: 1.5,

};

const textButtonStyle = {

  border: "none",

  padding: 0,

  background: "transparent",

  color: "#426a25",

  fontWeight: 700,

  cursor: "pointer",

};

const referenceStyle = {

  padding: 12,

  background: "#f4f7ef",

  borderRadius: 10,

  fontSize: 14,

  overflowWrap: "anywhere",

};

export default App;